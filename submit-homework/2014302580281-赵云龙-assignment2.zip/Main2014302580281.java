package getInfo;
import java.util.regex.*;
import java.io.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.*;
import org.jsoup.select.Elements;
public class Main2014302580281 {
    public static void main(String[]args) throws IOException
    {
    	FileOutputStream file=new FileOutputStream("introduce.txt"); 	
    	String url="http://staff.whu.edu.cn/show.jsp?lang=cn&n=Ai%20Xin%20Ping";
    	Document doc=Jsoup.connect(url).get();
    	String str=doc.select("p").first().text();
    	String name=doc.select("h3.title").first().text();
    	file.write(("姓名:"+name+"\n\r").getBytes());
    	System.out.println(name);
    	String phone=getdetail(str,"\\d+");
    	System.out.println(phone); 
    	file.write(("电话号:"+phone+"\n\r").getBytes());
    	String email=getdetail(str,"[a-zA-Z]+@[a-z.0-9]+");
    	System.out.println(email);
    	file.write(("E-mail:"+email+"\n\r").getBytes());	
    	String others=getdetail(str,"[^联]+");
    	System.out.println(others);
    	file.write((others+"\n\r").getBytes());
    	Elements divs=doc.select("div.szll_wz");
    	for(int i=1;i<divs.size();i++){	
			file.write((divs.get(i).text()+"\n\r").getBytes());
			System.out.println(divs.get(i).text()+"\r\n");
		}
    }
    private static String getdetail(String input,String way)
    {
    	
    	Pattern pattern = Pattern.compile(way);

        Matcher matcher = pattern.matcher(input);

        matcher.find();

        return matcher.group(0); 
    }
}
